#pragma once

#include "../defines.hpp"

namespace CrashReporter {
    void createAndSaveCrash();
};