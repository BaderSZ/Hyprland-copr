---
name: Feature request
about: Suggest a feature/change/idea
title: ''
labels: enhancement
assignees: ''

---

Please consult the issue guidelines at
https://github.com/vaxerski/Hyprland/blob/main/docs/ISSUE_GUIDELINES.md
BEFORE submitting.
